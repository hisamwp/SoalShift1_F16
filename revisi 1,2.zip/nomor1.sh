#!/bin/bash

unzip nature.zip

olah1=`ls ~/Downloads/nature | grep "[.]jpg$"`

for tes in $olah1
do
	`base64 -d ~/Downloads/nature/"$tes" | xxd -r > ~/Downloads/nature/"akhir$tes"`
done
